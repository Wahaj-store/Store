type Entry = { count: number; reset: number };
type RateLimitResult = { ok: boolean; remaining: number; reset: number };

const localStore = new Map<string, Entry>();
const REDIS_KEY_PREFIX = 'wahaj:rate-limit:';
const UPSTASH_TIMEOUT_MS = 1500;

function localRateLimit(key: string, limit: number, windowMs: number): RateLimitResult {
  const now = Date.now();
  const entry = localStore.get(key);

  if (!entry || entry.reset <= now) {
    localStore.set(key, { count: 1, reset: now + windowMs });
    return { ok: true, remaining: Math.max(0, limit - 1), reset: now + windowMs };
  }

  entry.count += 1;
  return {
    ok: entry.count <= limit,
    remaining: Math.max(0, limit - entry.count),
    reset: entry.reset,
  };
}

function upstashConfigured() {
  return Boolean(process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN);
}

export async function rateLimit(key: string, limit = 8, windowMs = 10 * 60 * 1000): Promise<RateLimitResult> {
  if (!upstashConfigured()) return localRateLimit(key, limit, windowMs);

  const url = process.env.UPSTASH_REDIS_REST_URL!.replace(/\/+$/, '');
  const token = process.env.UPSTASH_REDIS_REST_TOKEN!;
  const script = `
    local current = redis.call('INCR', KEYS[1])
    if current == 1 then redis.call('PEXPIRE', KEYS[1], ARGV[1]) end
    local ttl = redis.call('PTTL', KEYS[1])
    return { current, ttl }
  `;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), UPSTASH_TIMEOUT_MS);
  try {
    const response = await fetch(`${url}/pipeline`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify([['EVAL', script, '1', `${REDIS_KEY_PREFIX}${key}`, String(windowMs)]]),
      cache: 'no-store',
      signal: controller.signal,
    });

    if (!response.ok) throw new Error(`Upstash rate limit request failed: ${response.status}`);
    const payload = await response.json() as Array<{ result?: [number, number] }>;
    const result = payload[0]?.result;
    if (!Array.isArray(result) || result.length < 2) throw new Error('Invalid Upstash rate limit response');

    const count = Number(result[0]);
    const ttl = Math.max(1, Number(result[1]));
    return {
      ok: count <= limit,
      remaining: Math.max(0, limit - count),
      reset: Date.now() + ttl,
    };
  } catch {
    // Keep the store available if Redis is temporarily unavailable. Production
    // deployments should configure monitoring for this fallback condition.
    return localRateLimit(key, limit, windowMs);
  } finally {
    clearTimeout(timeout);
  }
}

export function getClientKey(req: Request) {
  return (
    req.headers.get('x-real-ip')?.trim() ||
    req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    'unknown'
  ).slice(0, 128);
}
